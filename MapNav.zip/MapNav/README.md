# MapNav

Google Maps-style navigation app. Leaflet map (CARTO Voyager tiles), OSRM routing, Photon search.

## Get the APK
**Option A: Android Studio** - open this folder, wait for Gradle sync, then Build > Build APK(s).
Output: app/build/outputs/apk/debug/app-debug.apk

**Option B: GitHub (no install)** - push this folder to a new GitHub repo. Open the Actions tab,
run "Build APK", and download MapNav-debug-apk from the finished run.

Then copy the APK to your phone and allow "install unknown apps".

## Features
- Search with autocomplete; long-press the map to drop a pin
- Drive / Bike / Walk, up to 3 route alternatives
- Smart stop order: add stops and the app reorders them for the shortest trip
- Arrive-by planner: tells you when to leave (15% buffer)
- Turn-by-turn with voice, live location, automatic rerouting, ETA

## Notes
Routing and search use free public servers (OSRM / Photon), fine for personal use. Swap the
URLs at the top of app/src/main/assets/index.html to use your own. No live-traffic data.
